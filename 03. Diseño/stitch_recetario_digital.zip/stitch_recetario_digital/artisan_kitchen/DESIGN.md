---
name: Artisan Kitchen
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#424843'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#727972'
  outline-variant: '#c2c8c0'
  surface-tint: '#466550'
  primary: '#163422'
  on-primary: '#ffffff'
  primary-container: '#2d4b37'
  on-primary-container: '#99baa1'
  inverse-primary: '#adcfb4'
  secondary: '#944a00'
  on-secondary: '#ffffff'
  secondary-container: '#fc8f34'
  on-secondary-container: '#663100'
  tertiary: '#2f2f2a'
  on-tertiary: '#ffffff'
  tertiary-container: '#454540'
  on-tertiary-container: '#b4b2ac'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c8ebd0'
  primary-fixed-dim: '#adcfb4'
  on-primary-fixed: '#022110'
  on-primary-fixed-variant: '#2f4d39'
  secondary-fixed: '#ffdcc5'
  secondary-fixed-dim: '#ffb783'
  on-secondary-fixed: '#301400'
  on-secondary-fixed-variant: '#713700'
  tertiary-fixed: '#e5e2db'
  tertiary-fixed-dim: '#c9c6c0'
  on-tertiary-fixed: '#1c1c18'
  on-tertiary-fixed-variant: '#474742'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-lg:
    fontFamily: EB Garamond
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: EB Garamond
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 42px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: EB Garamond
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-sm:
    fontFamily: EB Garamond
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  instruction-step:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 28px
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
  stack-sm: 8px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style
The design system is built for a modern culinary platform that bridges the gap between traditional heritage and contemporary lifestyle. The brand personality is **warm, professional, and inspiring**. It aims to evoke the feeling of a high-end editorial food magazine while remaining highly functional for active cooking.

The design style is **Modern Minimalist with Tactile accents**. It leverages significant whitespace to let high-quality food photography breathe, while using organic color blocks and refined typography to establish authority. The UI should feel like a clean kitchen counter: organized, inviting, and ready for creativity.

**Key Principles:**
- **Photography First:** UI elements are secondary to imagery; containers should never compete with the food.
- **Editorial Polish:** High-contrast typography pairings that mimic premium publishing.
- **Organic Precision:** A balance of soft shapes and structured grids to reflect both the nature of ingredients and the science of cooking.

## Colors
The palette is rooted in nature and culinary psychology. The **Primary Color (Forest Moss)** provides a professional, grounded foundation reminiscent of fresh herbs and sustainability. The **Secondary Color (Burnt Clementine)** serves as a high-energy accent designed to stimulate appetite and highlight primary calls to action.

The **Tertiary Color (Almond Flour)** is a warm off-white used for surfaces to reduce eye strain and provide a softer, more organic feel than pure white. Neutrals are kept slightly warm to maintain the "kitchen hearth" atmosphere.

- **Primary:** Use for headers, navigation, and deep-toned backgrounds.
- **Secondary/Accent:** Use for "Save Recipe," "Start Cooking," and interactive states.
- **Backgrounds:** Favor the tertiary off-white for main content areas to enhance the premium, paper-like feel.

## Typography
This design system employs a sophisticated pairing of **EB Garamond** for editorial flair and **Plus Jakarta Sans** for functional clarity.

- **The Serif (EB Garamond):** Used for recipe titles, section headers, and quotes. It communicates tradition, quality, and the "story" behind the food.
- **The Sans (Plus Jakarta Sans):** Used for ingredient lists, step-by-step instructions, and UI labels. Its modern, friendly geometry ensures high legibility even when the user is glancing at a screen from a distance while cooking.

**Instructional Hierarchy:**
Recipe steps should use `instruction-step` with increased line height to ensure users don't lose their place. Use `label-caps` for metadata like "PREP TIME" or "DIFFICULTY" to create a clear visual distinction from narrative text.

## Layout & Spacing
The layout follows a **structured fluid grid** that prioritizes scanning. 

- **Desktop:** A 12-column grid with generous 48px margins to create a "letterboxed" editorial feel.
- **Tablet:** 8-column grid with 32px margins.
- **Mobile:** 4-column grid with 16px margins. 

**Vertical Rhythm:** Use a base 8px unit. Components should be separated by `stack-md` (24px) for related items and `stack-lg` (48px) for major sections. Recipe instruction steps should have extra breathing room to emphasize the "one step at a time" philosophy.

**Image Aspect Ratios:** Maintain a 4:3 or 16:9 ratio for recipe hero images to ensure consistency in the feed.

## Elevation & Depth
In this design system, depth is achieved through **Tonal Layers** rather than heavy shadows, maintaining a clean and "organic" aesthetic.

- **Base Layer:** The Tertiary (Almond) color serves as the canvas.
- **Content Cards:** Use white backgrounds with extremely soft, low-opacity shadows (Blur 20px, Spread 0, Opacity 4%, Color: Primary Mix) to appear subtly lifted from the surface.
- **Interactive Elements:** Buttons and active chips use a 2px solid border or a slight color shift rather than deep shadows.
- **Modals & Overlays:** Use a heavy backdrop blur (20px) with a semi-transparent Primary Color tint (10% opacity) to keep the focus on the task while maintaining a connection to the visual context.

## Shapes
The shape language is **Soft and Natural**. Standard UI elements like buttons and input fields use a `0.5rem` radius to feel approachable. Large-scale elements like recipe cards and hero sections use `rounded-lg` (1rem) to mimic the softened corners of kitchenware and organic ingredients. 

Icons should follow a medium-stroke weight with rounded terminals to match the typography's friendly nature.

## Components
- **Primary Buttons:** Solid Burnt Clementine background with white text. High contrast to denote the most important action (e.g., "Save Recipe").
- **Secondary Buttons:** Ghost style with a 1.5px Forest Moss border. Used for secondary actions like "Print" or "Share."
- **Recipe Cards:** Vertical orientation. Image on top, followed by a category tag in `label-caps`, then the title in Serif. Use a subtle hover state that slightly scales the image within its container.
- **Ingredient List:** Checkable rows with a custom "leaf" icon for the checkbox. Tapping an ingredient strikes it through and lowers its opacity to 50%.
- **Instruction Steps:** Numbered lists using a large, low-opacity serif number as a background element for each step, ensuring the user's progress is visually anchored.
- **Difficulty Badges:** Small pill-shaped chips using a tonal scale of the Primary Green (Light for easy, Medium for moderate, Dark for hard).
- **Nutritional Panel:** A clean horizontal strip with light borders separating key metrics (Calories, Protein, etc.) using `label-caps` for headers.